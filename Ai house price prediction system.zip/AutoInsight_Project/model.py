import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import LabelEncoder
import pickle

# Load dataset
data = pd.read_csv("data.csv")

# Clean column names
data.columns = data.columns.str.strip().str.lower()

print("Columns:", data.columns.tolist())

# Check required columns
required_cols = [
    "city","lot_area","quality","year_built","living_area",
    "rooms","bedrooms","bathrooms","fireplace","garage","porch","price"
]

for col in required_cols:
    if col not in data.columns:
        print(f"❌ Missing column: {col}")
        exit()

# Encode city
encoder = LabelEncoder()
data["city"] = encoder.fit_transform(data["city"])

# Features
X = data[[
    "city","lot_area","quality","year_built","living_area",
    "rooms","bedrooms","bathrooms","fireplace","garage","porch"
]]

# Target
y = data["price"]

# Train model
model = LinearRegression()
model.fit(X, y)

# Save model
with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

# Save encoder (IMPORTANT)
with open("encoder.pkl", "wb") as f:
    pickle.dump(encoder, f)

print("✅ model.pkl created")
print("✅ encoder.pkl created")
print("🎉 Training complete!")