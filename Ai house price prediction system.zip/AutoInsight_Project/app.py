import streamlit as st
import pickle
import numpy as np
import os

# ---------------- PAGE CONFIG ----------------
st.set_page_config(page_title="AI House Price Predictor", layout="wide")

# ---------------- CUSTOM CSS ----------------
st.markdown("""
<style>
.stApp {
    background: linear-gradient(to right, #1f4037, #99f2c8);
    font-family: 'Segoe UI';
}

.title {
    text-align: center;
    font-size: 40px;
    font-weight: bold;
    color: #003333;
}

.card {
    background: rgba(255,255,255,0.7);
    padding: 15px;
    border-radius: 12px;
    margin-bottom: 10px;
}

.result {
    background: #003333;
    color: #00FFAA;
    padding: 25px;
    border-radius: 15px;
    text-align: center;
    font-size: 28px;
    font-weight: bold;
}

.stButton>button {
    background: linear-gradient(90deg, #00FFAA, #00cc88);
    color: black;
    border-radius: 10px;
    height: 3em;
    width: 100%;
    font-size: 18px;
    font-weight: bold;
}
</style>
""", unsafe_allow_html=True)

# ---------------- TITLE ----------------
st.markdown('<div class="title">🏠 AI House Price Prediction System</div>', unsafe_allow_html=True)
st.write("")

# ---------------- LOAD MODEL & ENCODER ----------------
try:
    model = pickle.load(open("model.pkl", "rb"))
    encoder = pickle.load(open("encoder.pkl", "rb"))
except:
    st.error("❌ Model or encoder not found. Run model.py first.")
    st.stop()

# ---------------- SIDEBAR ----------------
st.sidebar.header("📊 Enter Property Details")

city = st.sidebar.selectbox("City", [
    "Mumbai","Pune","Nashik","Nagpur","Thane",
    "Aurangabad","Solapur","Kolhapur"
])

lot_area = st.sidebar.number_input("Lot Area", value=1000)
quality = st.sidebar.slider("Quality (1-10)", 1, 10, 5)
year_built = st.sidebar.number_input("Year Built", 1900, 2025, 2010)
living_area = st.sidebar.number_input("Living Area", value=1000)
rooms = st.sidebar.number_input("Rooms", value=5)
bedrooms = st.sidebar.number_input("Bedrooms", value=3)
bathrooms = st.sidebar.number_input("Bathrooms", value=2)
fireplace = st.sidebar.selectbox("Fireplace", [0, 1])
garage = st.sidebar.number_input("Garage Area", value=0)
porch = st.sidebar.number_input("Porch Area", value=0)

# ---------------- MAIN LAYOUT ----------------
col1, col2 = st.columns(2)

with col1:
    st.markdown('<div class="card">🏠 Property Overview</div>', unsafe_allow_html=True)
    st.write(f"📍 City: **{city}**")
    st.write(f"📏 Lot Area: **{lot_area} sq.ft**")
    st.write(f"⭐ Quality: **{quality}/10**")
    st.write(f"📅 Year Built: **{year_built}**")

with col2:
    st.markdown('<div class="card">🛋 Interior Details</div>', unsafe_allow_html=True)
    st.write(f"🏠 Living Area: **{living_area} sq.ft**")
    st.write(f"🚪 Rooms: **{rooms}**")
    st.write(f"🛏 Bedrooms: **{bedrooms}**")
    st.write(f"🚿 Bathrooms: **{bathrooms}**")

st.markdown('<div class="card">🚗 Additional Features</div>', unsafe_allow_html=True)
st.write(f"🔥 Fireplace: **{fireplace}** | 🚗 Garage: **{garage} sq.ft** | 🌳 Porch: **{porch} sq.ft**")

st.write("")

# ---------------- PREDICTION ----------------
if st.button("🚀 Predict Price"):
    try:
        city_encoded = encoder.transform([city])[0]

        input_data = np.array([[ 
            city_encoded, lot_area, quality, year_built,
            living_area, rooms, bedrooms, bathrooms,
            fireplace, garage, porch
        ]])

        prediction = model.predict(input_data)

        st.markdown(
            f'<div class="result">💰 Estimated Price: ₹ {int(prediction[0]):,}</div>',
            unsafe_allow_html=True
        )

    except Exception as e:
        st.error(f"Error: {e}")

# ---------------- FOOTER ----------------
st.markdown("---")
st.markdown("✨ Developed using Python, Machine Learning & Streamlit")